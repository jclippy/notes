#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

extern BYTE START_OF_LOADER[];
extern ULONG SIZE_OF_LOADER;

LPCSTR pszPathToNotepad = "C:\\WINDOWS\\system32\\notepad.exe";

/**
	@brief	This routine takes in a null terminated string which is the full path to the
			DLL that we are going to inject. This DLL will be memory mapped and a buffer of
			size (SIZE_OF_LOADER + filesize(Dll)) will be allocated using MALLOC. The contents
			of the DLL loader and DLL will be copied in to the malloced buffer and returned
			via the OUT parameters.

			Caller must remember to FREE the returned buffer.

	@param	[IN] pszPathToTestDll - Full path to the DLL we wish to mobilize.
	@param	[OUT] ppMobileCodeBuffer - Pointer to a location that will be assigned a pointer to the buffer
			that contains the DLL loader concatenated with the DLL.
	@param	[OUT] dwSizeOfMobileCode - Length of the buffer in bytes.

	@retval
*/
ULONG BuildInjectionBuffer(PCHAR pszPathToTestDll, PVOID *ppMobileCodeBuffer, PDWORD dwSizeOfMobileCode)
{
	ULONG ulRetVal = ERROR_SUCCESS;
	HANDLE hDll = INVALID_HANDLE_VALUE;
	HANDLE hFileMap = INVALID_HANDLE_VALUE;
	LPVOID lpDllBase = NULL;
	DWORD dwFileSizeLo = 0;
	DWORD dwFileSizeHi = 0;
	PBYTE pBuffer = NULL;
	
	hDll = CreateFileA(pszPathToTestDll, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(INVALID_HANDLE_VALUE != hDll)
	{
		dwFileSizeLo = GetFileSize(hDll, &dwFileSizeHi);
		if(dwFileSizeLo && (0==dwFileSizeHi))
		{
			printf(" [*] Opened '%s', [%d bytes]\n", pszPathToTestDll, dwFileSizeLo);
			hFileMap = CreateFileMappingW(hDll, NULL, PAGE_READONLY, 0, 0, NULL);
		}
		
		if(NULL != hFileMap)
		{
			lpDllBase = MapViewOfFile( hFileMap, FILE_MAP_READ, 0, 0, 0 );
			if(NULL != lpDllBase)
			{
				pBuffer = malloc(SIZE_OF_LOADER + dwFileSizeLo);
				if(NULL != pBuffer)
				{
					/* Copy the loader into the buffer first */
					memcpy(pBuffer, START_OF_LOADER, SIZE_OF_LOADER);

					/* Next, copy the DLL */
					memcpy(pBuffer + SIZE_OF_LOADER, lpDllBase, dwFileSizeLo);

					/* Set our variables */
					*ppMobileCodeBuffer = pBuffer;
					*dwSizeOfMobileCode = (SIZE_OF_LOADER + dwFileSizeLo);
				}
				else
				{
					printf(" [-] Out of memory\n\n");
					ulRetVal = 3;
				}
			}
			else
			{
				printf(" [-] Unable to MapViewOfFile. GetLastError returned: 0x%08x\n\n", GetLastError());
				ulRetVal = 3;
			}
		}
		else
		{
			printf(" [-] Unable to CreateFileMapping. GetLastError returned: 0x%08x\n\n", GetLastError());
			ulRetVal = 2;
		}
	}
	else
	{
		printf(" [-] Unable to open file '%s'. GetLastError returned: 0x%08x\n\n", pszPathToTestDll, GetLastError());
		ulRetVal = 1;
	}
	
	if(NULL != lpDllBase)
	{
		UnmapViewOfFile(lpDllBase);
	}
	if(INVALID_HANDLE_VALUE != hFileMap)
	{
		CloseHandle(hFileMap);
	}
	if(INVALID_HANDLE_VALUE != hDll)
	{
		CloseHandle(hDll);
	}

	return ulRetVal;
}

/**
	@brief	Mobilized Code method

			The main injection routine. This will VirtualAlloc in the remote process
			and then write the DLL loader and DLL into it. CreateRemoteThread will
			cause the loader to begin to execute which will load our DLL from memory.

	@param	[IN] hProcess - Handle to the remote process, the one we are injecting into.
	@param	[IN] pszDllTOInject - Full path to the DLL that will be injected.

	@retval	ULONG - ERROR_SUCCESS on success, nonzero on failure.
*/
ULONG InjectDllAsMobileCode(HANDLE hProcess, PCHAR pszDllToInject)
{
	ULONG ulRetVal = ERROR_SUCCESS;
	PBYTE pMobileCode = NULL;
	DWORD dwSizeOfMobileCode = 0;
	PCHAR pRemoteMem = NULL;
	HANDLE hThread = INVALID_HANDLE_VALUE;

	/* Build the buffer with our loader & Dll */
	ulRetVal = BuildInjectionBuffer(pszDllToInject, &pMobileCode, &dwSizeOfMobileCode);


	if((ERROR_SUCCESS == ulRetVal) && (pMobileCode))
	{
		/* Write code into process */
		pRemoteMem = VirtualAllocEx(hProcess, NULL, dwSizeOfMobileCode, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		if(WriteProcessMemory(hProcess, pRemoteMem, pMobileCode, dwSizeOfMobileCode, NULL))
		{
			/* Create thread on mobilized code */
			hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)pRemoteMem, 0, 0, 0);
			if(hThread)
			{
				(VOID)WaitForSingleObject(hThread, INFINITE);
				CloseHandle(hThread);
			}
		}
		else
		{
			printf(" [-] Unable to VirtualAllocEx in remote process %d.\n\n", GetLastError());
			ulRetVal = 2;
		}
		
		/* Remember to free the buffer */
		free(pMobileCode);
	}
	else
	{
		printf(" [-] BuildInjectionBuffer returned %d [pMobileCode: 0x%p].\n\n", ulRetVal, pMobileCode);
		ulRetVal = 1;
	}

	return ulRetVal;
}

/**
	@brief	StartTestProcess calls CreateProcess and returns a handle to the new process

	@param	[IN] pszCmd - Full path to the executable to run.

	@retval	BOOL - True on success, false if there was an error.
*/
HANDLE StartTestProcess(IN LPCSTR pszCmd)
{
	BOOL bResult = FALSE;
	STARTUPINFOA startupInfo = {0};
	PROCESS_INFORMATION processInfo = {0};
	HANDLE hRetVal = INVALID_HANDLE_VALUE;
	
	/* Startup info structure used for CreateProcess. Set the size in bytes, then call GetStartupInfo to fill out the rest*/
	startupInfo.cb = sizeof(STARTUPINFOA);
	GetStartupInfoA(&startupInfo);
	
	bResult = CreateProcessA(NULL, (LPSTR)pszCmd, NULL, NULL, 0, 0, NULL, NULL, &startupInfo, &processInfo);
	if(bResult)
	{
		CloseHandle(processInfo.hThread);
		hRetVal = processInfo.hProcess;
	}
	
	return hRetVal;
}

void
PrintUsage(IN PCSTR argv0)
{
	printf("\
usage: %s DLL_PATH\n\
	DLL_PATH	The path (absolute or relative) path to the DLL to inject.\n",
		   argv0);

	return;
}

/**
	@brief	main

	@param	[in] argc - Count of arguments.
	@param	[in] argv - Char array of command line arguments.
  
	@retval	INT
*/
INT __cdecl main(INT argc, PCHAR argv[])
{
	INT iRetVal = ERROR_SUCCESS;
	HANDLE hCalc = NULL;
	DWORD dwPid = 0;
	PSTR pszDllPath;
	CHAR pszPathToTestDll[MAX_PATH] = {0};

	/* Check parameters. */
	if (2 > argc)
	{
		PrintUsage(argv[0]);
		return ERROR_INVALID_PARAMETER;
	}
	pszDllPath = argv[1];

	/* Translate the relative path to an absolute one */
	if(GetFullPathNameA(pszDllPath, MAX_PATH, pszPathToTestDll, NULL))
	{
		/* Test with the Richter method */
		hCalc = StartTestProcess(pszPathToNotepad);
		if(NULL != hCalc)
		{
			printf("Calc loaded. Attach a debugger, resume the process, and press any key.\n");
			_getch();

			if(ERROR_SUCCESS == InjectDllAsMobileCode(hCalc, pszPathToTestDll))
			{
				printf("Injected via the mobilized code method.\n\n");
			}
			CloseHandle(hCalc);
		}
	}
	else
	{
		printf(" [-] Unable to translate the relative DLL path into an absolute %d.\n\n", GetLastError());
	}

	return iRetVal;
}

