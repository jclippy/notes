#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#define LIBPATH ".\\Lab_10.dll"

INT log(INT level, PCSTR message)
{
    PCSTR lvl;
    
    if (level >= 3) {
        printf("GOT FATAL ERROR: %s\n", message);
        exit(-1);
    }
    switch (level) {
    case 1:
        lvl = "WRN";
        break;
    case 2:
        lvl = "ERR";
        break;
    default:
        lvl = "DBG";
        break;
    }

    printf("[%s]: %s\n", lvl, message);

    if (level % 2) {
        return -1;
    }
    return 0;
}

INT main(INT argc, PCHAR argv[])
{
    HMODULE debuglib = NULL;
    INT res = -1;

    // load debug dll
    debuglib = LoadLibraryA(LIBPATH);
    if (debuglib) {
        printf("Loaded DLL\n");
    }

    if (log(2, "Log 1"))
    {
        printf("Log returned an error\n");
        exit(-1);
    }

    if (log(3, "Log 2"))
    {
        printf("Log returned an error\n");
        exit(-1);
    }

    if (log(1, "Log 3"))
    {
        printf("Log returned an error\n");
        exit(-1);
    }

    if (log(0, "Log 4"))
    {
        printf("Log returned an error\n");
        exit(-1);
    }

    if (log(3, "Log 5"))
    {
        printf("Log returned an error\n");
        exit(-1);
    }

    if (debuglib) {
        FreeLibrary(debuglib);
    }

    log(0, "Log 6");

    printf("Success!");

    return res;
}