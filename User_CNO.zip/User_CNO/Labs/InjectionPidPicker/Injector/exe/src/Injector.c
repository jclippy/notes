#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "dispatcher.h"
#include "InjectionLib.h"

extern DWORD g_pid;

static
VOID
WINAPI
openTargetProc(DWORD pid)
{
    HANDLE hProcess;
    if((hProcess = OpenProcess(
            PROCESS_ALL_ACCESS,
            FALSE,
            pid
            )) == NULL)
    {
        printf("Could not OpenProcess\n");
    }
    else
    {
        printf("OpenedProcess!\n");
        CloseHandle(hProcess);
    }
}    

INT __cdecl main(INT argc, PCHAR argv[])
{

    Il_getDebugPriv();

    Inject_showPidPicker();
    
    openTargetProc(g_pid);

	return 0;
}
