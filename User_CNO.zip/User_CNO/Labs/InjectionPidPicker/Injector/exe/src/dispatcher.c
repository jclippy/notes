#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include "InjectionLib.h"
#include "resource.h"
#include <commctrl.h>

DWORD g_pid = 0;

/* Function prototypes for dispatch handlers. */
static void OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
static void OnDestroy(HWND hwnd);
static BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
static LRESULT OnNotify(HWND hwnd, int id, LPNMHDR pnmh);


/**
    ProcInfoListCallback
  */
static
DWORD WINAPI ProcInfoListCallback(IN PIL_PROCESS_INFORMATION pCurProcInfo, PVOID pContext)
{
    DWORD dwRet = 0;
    HWND hListBox = (HWND) pContext;
    LVITEM lvi = {0};
    CHAR strPid[25] = {0};
    INT idx = 0;

    lvi.mask = LVCF_TEXT;
    lvi.cchTextMax = 256;
    lvi.iItem = 0;
    lvi.iSubItem = 0;
    idx = (INT) SendMessage(hListBox, LVM_INSERTITEM, 0, (LPARAM)&lvi);
    
    sprintf(strPid, "%d", (ULONG_PTR)pCurProcInfo->ProcessId);
    lvi.pszText = strPid;

    (VOID) SendMessage(hListBox, LVM_SETITEMTEXT, idx, (LPARAM)&lvi);

    lvi.pszText = pCurProcInfo->ImageName;
    lvi.mask = LVCF_TEXT;
    lvi.iItem = 0;
    lvi.iSubItem = 1;

    (VOID) SendMessage(hListBox, LVM_SETITEMTEXT, idx, (LPARAM)&lvi);

    return dwRet;
}


/**
    DialogProc
  */
static
BOOL CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) 
{
    BOOL bHandled = TRUE;

    switch (message) 
    { 
        case WM_INITDIALOG:
            bHandled = (BOOL)HANDLE_WM_INITDIALOG(hDlg, wParam, lParam, OnInitDialog);
            break;

        case WM_NOTIFY:
            HANDLE_WM_NOTIFY(hDlg, wParam, lParam, OnNotify);
            break;
            
        case WM_COMMAND:
            HANDLE_WM_COMMAND(hDlg, wParam, lParam, OnCommand);
            break;

        case WM_DESTROY:
            HANDLE_WM_DESTROY(hDlg, wParam, lParam, OnDestroy);
            break;

        default:
            bHandled = FALSE;

    }

    return bHandled; 
} 

/**
    OnDestroy
  */
static
void OnDestroy(HWND hwnd)
{
    PostQuitMessage(0);
}

/**
    GetPidFromSelected
  */
static
DWORD GetPidFromSelected(HWND hwnd)
{
    LVITEM lvi = {0};
    INT idx = 0;
    HWND hListBox = NULL;
    DWORD pid = 0;
    CHAR strPid[25] = {0};

    hListBox = GetDlgItem(hwnd, IDC_LIST1);
    idx = (INT) SendMessage(hListBox, LVM_GETNEXTITEM, -1, MAKELPARAM(LVNI_SELECTED, 0));
    if (idx != -1)
    {
        lvi.mask = LVCF_TEXT;
        lvi.iSubItem = 0;
        lvi.pszText = strPid;
        lvi.cchTextMax = 25;
        lvi.iItem = idx;

        (VOID) SendMessage(hListBox, LVM_GETITEMTEXT, idx, (LPARAM)&lvi);
        pid = (DWORD) atoi(lvi.pszText);
        printf("Selected PID %d\n", pid);
    }

    return pid;
}

/**
    OnCommand
  */
static
void OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    switch (id)
    { 
        case IDOK:
            g_pid = GetPidFromSelected(hwnd);
             
        case IDCANCEL:
            DestroyWindow(hwnd);
            break;
    }
}

/**
    OnNotify
  */
static
LRESULT OnNotify(HWND hwnd, int id, LPNMHDR pnmh)
{
    /* Double clicked our list box. */
    if (IDC_LIST1 == pnmh->idFrom && NM_DBLCLK == pnmh->code)
    {
        g_pid = GetPidFromSelected(hwnd);

        /* Equal to clicking "OK". */
        DestroyWindow(hwnd);
    }

    return 0;
}

/**
    OnInitDialog
  */
static
BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
    DWORD dwRet = IL_SUCCESS;
    PIL_PROCESS_INFORMATION pSysProcInfos = NULL;
    HWND hListBox = NULL;
    LVCOLUMN lvCol = {0};
    LVITEM lvi = {0};
    INT idx = 0;
    CHAR strPid[25] = {0};
 
    hListBox = GetDlgItem(hwnd, IDC_LIST1);

    /* Select whole row */
    (VOID) SendMessageW(hListBox, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);

    /* Add PID column */
    lvCol.mask = LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;
    lvCol.cx = 0x28;
    lvCol.pszText = "PID";
    (VOID) SendMessage(hListBox, LVM_INSERTCOLUMN, 0, (LPARAM)&lvCol);
    
    /* Add Process Name columns */
    lvCol.cx = 0x100;
    lvCol.pszText = "Process";
    (VOID) SendMessage(hListBox, LVM_INSERTCOLUMN, 1, (LPARAM)&lvCol);

    dwRet = Il_getPidList(&pSysProcInfos);
    if (IL_SUCCESS != dwRet)
    {
        return FALSE;
    }

    dwRet = Il_iteratePidList(pSysProcInfos, ProcInfoListCallback, (PVOID)hListBox);
    if (IL_SUCCESS != dwRet)
    {
        return FALSE;
    }

    dwRet = Il_destroyPidList(&pSysProcInfos);
    if (IL_SUCCESS != dwRet)
    {
        return FALSE;
    }

    return TRUE;
}

/**
    Inject_showPidPicker
  */
DWORD
WINAPI
Inject_showPidPicker()
{
    BOOL bRet = FALSE;
    MSG msg = {0};
    HWND hwndDlg = NULL;

    hwndDlg = CreateDialog(NULL, 
                           MAKEINTRESOURCE(IDD_DIALOG1), 
                           NULL, 
                           (DLGPROC)DialogProc); 
    ShowWindow(hwndDlg, SW_SHOW);

    while ((bRet = GetMessage(&msg, NULL, 0, 0)) != 0) 
    {
        if (bRet == -1)
        {
            break;
        }
        else if (!IsWindow(hwndDlg) || !IsDialogMessage(hwndDlg, &msg)) 
        { 
            TranslateMessage(&msg); 
            DispatchMessage(&msg); 
        } 
    } 

    return 0;
}
