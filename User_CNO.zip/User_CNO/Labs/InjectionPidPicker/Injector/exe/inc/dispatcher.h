#ifndef _DISPATCHER_H_
#define _DISPATCHER_H_

#ifdef __cplusplus
extern "C" {
#endif

DWORD
WINAPI
Inject_showPidPicker();
    

#ifdef __cplusplus
}
#endif

#endif //_DISPATCHER_H_
