#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "NtUndoc.h"
#include "InjectionLib.h"

DWORD
WINAPI
Il_getDebugPriv()
{
    HANDLE hProcess;
    HANDLE hToken;
    DWORD dwRet = IL_SUCCESS; 

    __try
    {
        if(!OpenThreadToken(GetCurrentThread(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, FALSE, &hToken))
        {
            if (GetLastError() == ERROR_NO_TOKEN)
            {
                if (!ImpersonateSelf(SecurityImpersonation))
                {
                    dwRet = IL_FAILURE;
                    __leave;
                }

                if(!OpenThreadToken(GetCurrentThread(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, FALSE, &hToken))
                {
                    dwRet = IL_FAILURE;
                    __leave;
                }
            }
            else
            {
                dwRet = IL_FAILURE;
                __leave;
            }
         }

        // enable SeDebugPrivilege
        if(!Il_setPrivilege(hToken, SE_DEBUG_NAME, TRUE))
        {
            dwRet = IL_FAILURE;
        }
    }
    __finally
    {
        CloseHandle(hToken);
    }
    return dwRet;
}


DWORD
WINAPI
Il_setPrivilege(
    HANDLE hToken,          // access token handle
    LPCTSTR lpszPrivilege,  // name of privilege to enable/disable
    BOOL bEnablePrivilege   // to enable or disable privilege
    ) 
{
    DWORD dwRet = IL_SUCCESS;
    TOKEN_PRIVILEGES tp;
    LUID luid;

    __try
    {
        if ( !LookupPrivilegeValue( 
                NULL,            // lookup privilege on local system
                lpszPrivilege,   // privilege to lookup 
                &luid ) )        // receives LUID of privilege
        {
            printf("LookupPrivilegeValue error: %u\n", GetLastError() ); 
            dwRet = IL_FAILURE;
            __leave;
        }

        tp.PrivilegeCount = 1;
        tp.Privileges[0].Luid = luid;
        if (bEnablePrivilege)
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        else
            tp.Privileges[0].Attributes = 0;

        // Enable the privilege or disable all privileges.

        if ( !AdjustTokenPrivileges(
               hToken, 
               FALSE, 
               &tp, 
               sizeof(TOKEN_PRIVILEGES), 
               (PTOKEN_PRIVILEGES) NULL, 
               (PDWORD) NULL) )
        { 
            printf("AdjustTokenPrivileges error: %u\n", GetLastError() ); 
            dwRet = IL_FAILURE;
            __leave;

        } 

        if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)

        {
            printf("The token does not have the specified privilege. \n");
            dwRet = IL_FAILURE;
            __leave;
        }
    }
    __finally
    {

    }

    return dwRet;
}


DWORD WINAPI Il_iteratePidList(IN PIL_PROCESS_INFORMATION pProcList, FPLISTCALLBACK fpCallback, PVOID pContext)
{
    DWORD dwRet = IL_SUCCESS;
    PIL_PROCESS_INFORMATION pCurProcInfo = NULL;

    __try
    {
        if (!pProcList || !fpCallback)
        {
            dwRet = IL_INVALID_PARAMETER;
            __leave;
        }

        pCurProcInfo = (PIL_PROCESS_INFORMATION) CONTAINING_RECORD(pProcList->ProcessInfoEntry.Flink, IL_PROCESS_INFORMATION, ProcessInfoEntry);
        while(pCurProcInfo != pProcList)
        {
            dwRet = fpCallback(pCurProcInfo, pContext);
            pCurProcInfo = (PIL_PROCESS_INFORMATION) CONTAINING_RECORD(pCurProcInfo->ProcessInfoEntry.Flink, IL_PROCESS_INFORMATION, ProcessInfoEntry);
        }
    }
    __finally
    {

    }

    return dwRet;
}

DWORD WINAPI Il_destroyPidList(IN PIL_PROCESS_INFORMATION *pProcList)
{
    DWORD dwRet = IL_SUCCESS;
    PLIST_ENTRY pCurListEntry = NULL;
    PIL_PROCESS_INFORMATION pCurProcInfo = NULL;
    PIL_PROCESS_INFORMATION pHead = NULL;

    __try
    {
        if (!pProcList && !*pProcList)
        {
            dwRet = IL_INVALID_PARAMETER;
            __leave;
        }

        pHead = *pProcList;
        while(!IsListEmpty(&pHead->ProcessInfoEntry))
        {
            pCurListEntry = RemoveHeadList(&pHead->ProcessInfoEntry);
            pCurProcInfo = (PIL_PROCESS_INFORMATION) CONTAINING_RECORD(pCurListEntry, IL_PROCESS_INFORMATION, ProcessInfoEntry);

            /* Free the string. */
            free(pCurProcInfo->ImageName);

            /* Free the entry. */
            free(pCurProcInfo);
        }
    }
    __finally
    {
        /* Free the head. */
        if (IL_SUCCESS == dwRet)
        {
            free(pProcList);
            *pProcList = NULL;
        }
    }

    return dwRet;
}

DWORD WINAPI Il_getPidList(OUT PIL_PROCESS_INFORMATION *pProcList)
{
    NTSTATUS ntstatus = STATUS_INFO_LENGTH_MISMATCH;
    DWORD dwRet = IL_SUCCESS;
    NTQUERYSYSTEMINFORMATION NtQuerySystemInformation = NULL;
    PSYSTEM_PROCESS_INFORMATION pSysProcInfos = NULL;
    PSYSTEM_PROCESS_INFORMATION pCurSysProc = NULL;
    PIL_PROCESS_INFORMATION pProcListHead = NULL;
    PIL_PROCESS_INFORMATION pTmpEntry = NULL;
    CHAR *pszProcName = NULL;
    INT cbMultiByte = 0;
    DWORD i = 0;
    DWORD dwProcInfoCount = 1;
    ULONG retLen = 0;

    __try
    {
        /* Allocate inital list head */
        pProcListHead = (PIL_PROCESS_INFORMATION) malloc(sizeof(IL_PROCESS_INFORMATION));
        if (!pProcListHead)
        {
            dwRet = IL_OUT_OF_MEMORY;
            __leave;
        }

        /* Initialize list head */
        InitializeListHead(&pProcListHead->ProcessInfoEntry);


        /* Get NtQuerySystemInformation function pointer */
        NtQuerySystemInformation = (NTQUERYSYSTEMINFORMATION) GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtQuerySystemInformation");
        if (!NtQuerySystemInformation)
        {
            dwRet = IL_FUNC_NOT_FOUND;
            __leave;
        }

        /* Obtain process information buffer */
        while (STATUS_INFO_LENGTH_MISMATCH == ntstatus)
        {
            dwProcInfoCount *= 2;
            pSysProcInfos = (PSYSTEM_PROCESS_INFORMATION)calloc(sizeof(SYSTEM_PROCESS_INFORMATION), dwProcInfoCount);
            if (!pSysProcInfos)
            {
                dwRet = IL_OUT_OF_MEMORY;
                __leave;
            }

            ntstatus = NtQuerySystemInformation(SystemProcessesAndThreadsInformation, pSysProcInfos, sizeof(SYSTEM_PROCESS_INFORMATION)*dwProcInfoCount, &retLen);
            if (STATUS_INFO_LENGTH_MISMATCH == ntstatus)
            {
                free(pSysProcInfos);
            }
        }

        /* Process the elements, converting to IL_PROCESS_INFORMATION structures in a list. */
        for (pCurSysProc = pSysProcInfos; pCurSysProc->NextEntryOffset; pCurSysProc = (PSYSTEM_PROCESS_INFORMATION)(((PBYTE)pCurSysProc) + pCurSysProc->NextEntryOffset))
        {
            printf("[%p] %p %S\n", pCurSysProc->InheritedFromProcessId, pCurSysProc->ProcessId, pCurSysProc->ImageName.Buffer);

            if (!pCurSysProc->ImageName.Buffer)
            {
                continue;
            }

            /* Allocate enough space for the IL_PROCESS_INFORMATION structure as well
             * as each IL_THREAD_INFORMAITON structure */
            pTmpEntry = (PIL_PROCESS_INFORMATION) malloc(sizeof(IL_PROCESS_INFORMATION) + 
                        (sizeof(IL_THREAD_INFORMATION) * (pCurSysProc->NumberOfThreads-1)));
            if (!pTmpEntry)
            {
                dwRet = IL_OUT_OF_MEMORY;
                __leave;
            }

            /* Convert the UNICODE_STRING ImageName to an ascii string. */
            cbMultiByte = WideCharToMultiByte(CP_ACP, 
                                              0, 
                                              pCurSysProc->ImageName.Buffer, 
                                              (pCurSysProc->ImageName.Length/sizeof(USHORT)),
                                              NULL,
                                              0,
                                              NULL,
                                              NULL);
            if (0 == cbMultiByte)
            {
                dwRet = IL_ERROR_STRING_CONV;
                __leave;
            }

            /* NULL term not included since we passed in a length to WC2MB */
            cbMultiByte += sizeof(CHAR);
            pszProcName = (CHAR*) malloc(cbMultiByte);
            if (!pszProcName)
            {
                dwRet = IL_OUT_OF_MEMORY;
                __leave;
            }

            /* Actual conversion */
            cbMultiByte = WideCharToMultiByte(CP_ACP, 
                                              0, 
                                              pCurSysProc->ImageName.Buffer, 
                                              (pCurSysProc->ImageName.Length/sizeof(USHORT)),
                                              pszProcName,
                                              cbMultiByte,
                                              NULL,
                                              NULL);
            if (0 == cbMultiByte)
            {
                dwRet = IL_ERROR_STRING_CONV;
                __leave;
            }

            /* Fill out all the structure fields. */
            pTmpEntry->NumberOfThreads = pCurSysProc->NumberOfThreads;
            pTmpEntry->ImageName = pszProcName;
            pTmpEntry->ProcessId = pCurSysProc->ProcessId;
            pTmpEntry->InheritedFromProcessId = pCurSysProc->InheritedFromProcessId;

            for (i = 0; i < pCurSysProc->NumberOfThreads; i++)
            {
                pTmpEntry->Threads[i].StartAddress = pCurSysProc->Threads[i].StartAddress;
                pTmpEntry->Threads[i].UniqueProcess = pCurSysProc->Threads[i].ClientId.UniqueProcess;
                pTmpEntry->Threads[i].UniqueThread = pCurSysProc->Threads[i].ClientId.UniqueThread;
            }

            InsertTailList(&pProcListHead->ProcessInfoEntry, &pTmpEntry->ProcessInfoEntry);
        }



    }
    __finally
    {
        /* Always free the buffer used for NtQuerySystemInformation. */
        free(pSysProcInfos);

        if (IL_SUCCESS != dwRet)
        {
            /* Destroy the list, if any parts exist. */
            Il_destroyPidList(&pProcListHead);
            printf("Left with dwRet: %d GLE: %d", dwRet, GetLastError());
        }
        else
        {
            /* Set the return pointer. */
            *pProcList = pProcListHead;
        }
    }
    
    return dwRet;
}
