#ifndef _INJECTIONLIB_H_
#define _INJECTIONLIB_H_

#ifdef __cplusplus
extern "C" {
#endif

#define IL_SUCCESS 0
#define IL_OUT_OF_MEMORY 1
#define IL_FUNC_NOT_FOUND 2
#define IL_FAILURE 3
#define IL_ERROR_STRING_CONV 4
#define IL_INVALID_PARAMETER 5

typedef struct _IL_THREAD_INFORMATION {
    PVOID StartAddress;
    HANDLE UniqueProcess;
    HANDLE UniqueThread;
} IL_THREAD_INFORMATION, *PIL_THREAD_INFORMATION;

typedef struct _IL_PROCESS_INFORMATION {
    LIST_ENTRY ProcessInfoEntry;
    ULONG NumberOfThreads;
    CHAR *ImageName;
    HANDLE ProcessId;
    HANDLE InheritedFromProcessId;
    IL_THREAD_INFORMATION Threads[1];
} IL_PROCESS_INFORMATION, *PIL_PROCESS_INFORMATION;

typedef DWORD (WINAPI *FPLISTCALLBACK)(IN PIL_PROCESS_INFORMATION pCurProcInfo, PVOID pContext);

DWORD WINAPI Il_getPidList(OUT PIL_PROCESS_INFORMATION *pProcList);
DWORD WINAPI Il_iteratePidList(IN PIL_PROCESS_INFORMATION pProcList, FPLISTCALLBACK fpCallback, PVOID pContext);
DWORD WINAPI Il_destroyPidList(IN PIL_PROCESS_INFORMATION *pProcList);
DWORD WINAPI Il_setPrivilege(IN HANDLE hToken, IN LPCTSTR lpszPrivilege, IN BOOL bEnablePrivilege);
DWORD WINAPI Il_getDebugPriv();

#ifdef __cplusplus
}
#endif

#endif //_INJECTIONLIB_H_
