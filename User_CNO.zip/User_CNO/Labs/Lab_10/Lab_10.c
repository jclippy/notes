#include <windows.h>
#include <stdio.h>
#include "hooking.h"

#define LOG_OFF     0x011230

PENTRY_STUB_TRAMP g_stub = NULL;

PVOID findTargetBase()
{
    PVOID* peb = __readgsqword(0x60);
    return peb[2];
}

INT logWrapper(INT level, PCSTR message)
{
    if (level >= 3) {
        level = 2;
    }

    ((INT(*)(INT,PCSTR))(g_stub->pTrampoline))(level, message);
    return 0;
}

/* Students fill out this function */
VOID attachHooks(PBYTE targetbase)
{
    DWORD res = 0;
    printf("Attaching hooks\n");

    res = EntryStub_create(&g_stub, targetbase + LOG_OFF);
    if (res) {
        printf("Got error %x while creating EntryStub\n", res);
        return;
    }

    res = !EntryStub_hook(g_stub, logWrapper);
    if (res) {
        printf("Got error %x while hooking Log\n", res);
        return;
    }

    printf("Attached hooks\n");
}

VOID removeHooks(PBYTE targetbase)
{
    DWORD res = 0;
    printf("removing hooks\n");

    res = !EntryStub_unhook(g_stub);
    if (res) {
        printf("Got error %x while unhooking Log\n", res);
        return;
    }

    EntryStub_free(g_stub);

    printf("removed hooks\n");
}

BOOL WINAPI DllMain(HINSTANCE hDllBase,
    DWORD dwReason,
    LPVOID lpReserved)
{
    PVOID targetbase = findTargetBase();
    UNREFERENCED_PARAMETER(hDllBase);
    UNREFERENCED_PARAMETER(lpReserved);

    /* Break */
    //__debugbreak();

    switch (dwReason)
    {
    case DLL_THREAD_ATTACH:
        break;
    case DLL_THREAD_DETACH:
        break;
    case DLL_PROCESS_DETACH:
        // remove hooks here
        removeHooks((PBYTE)targetbase);
        break;
    case DLL_PROCESS_ATTACH:
        // attach hooks
        attachHooks((PBYTE)targetbase);
        break;
    }

    return TRUE;
}