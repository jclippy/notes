#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

extern PVOID WINAPI findKernel32();

/**
	@brief	main

	@param	[in] argc - Count of arguments.
	@param	[in] argv - Char array of command line arguments.
  
	@retval	INT
*/
INT __cdecl main(INT argc, PCHAR argv[])
{
	INT iRetVal = 0;

	printf("KERNEL32: %p\n", GetModuleHandleA("kernel32"));
	printf("KERNEL32: %p\n", findKernel32());

	return iRetVal;
}