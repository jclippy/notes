#include <windows.h>
#include <stdio.h>

/* This is the value passed into the DLL as the load reason */
#define MOBILE_CODE_ENTRY 4

/**
	@brief	Prints out the name of the executable that this DLL is loaded in.

*/
DWORD WINAPI processInfo()
{
	CHAR pszModuleName[MAX_PATH];
	DWORD dwModNameLen = 0;
	LPSTR pszMessage= NULL;
	
	dwModNameLen = GetModuleFileNameA(NULL, pszModuleName, MAX_PATH);
	
	(VOID)MessageBoxA(NULL, pszModuleName, "This DLL is running in:", MB_OK);
	
	return ERROR_SUCCESS;
}

/**
	@brief DLL Main

*/
BOOL WINAPI DllMain(HINSTANCE hDllBase,
					DWORD dwReason,
					LPVOID lpReserved)
{
	/* Break */

	switch(dwReason)
	{
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			break;
		case DLL_PROCESS_ATTACH:
		case MOBILE_CODE_ENTRY:
			(VOID)processInfo();
			break;
	}
	
	return TRUE;
}